import React from "react";
import Search from "./components/search/Search";

function App() {
	return (
		<div className="container">
			<Search />
		</div>
	);
}

export default App;
