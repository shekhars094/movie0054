# Deployment Process for Heroku

1. git add .

2. git commit -m "commit message"

3. heroku create APP_NAME --buildpack mars/create-react-app

4. git push heroku master
